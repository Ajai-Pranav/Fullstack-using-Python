from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib import messages

# Create your views here.
def login(request):
	return render(request,'login.html')

def checklogin(request):
	if request.method=="POST":
		u=request.POST["txtuser"]
		p=request.POST["txtpassword"]
		if u=="admin" and p=="admin":
			res="Valid Login"
			return HttpResponseRedirect("/markinput")
			#return render(request,'login.html',{'result':res})
		else:
			#res="Invalid Login"
			messages.success(request,"INValid Login")
			return render(request,'login.html',{})

def marklist(request):
	return render(request,'markinput.html')



def mark(request):
	if request.method=="POST":
		n=request.POST["txtname"]
		s=request.POST["txtstd"]
		t=request.POST["tamil"]
		e=request.POST["english"]
		m=request.POST["math"]
		ss=request.POST["ss"]
		evs=request.POST["evs"]
		total=(int(t)+int(e)+int(m)+int(ss)+int(evs))
		avg=total/5
		result=""
		if (int(t)>=40 and int(e)>=40 and int(m)>=40 and int(ss)>=40 and int(evs)>=40):
			result="PASS"
		else :
			result="FAIL"	
		return render(request,'marksheet.html',{'name':n,'std':s,'tamil':t,'english':e,'math':m,'ss':ss,'evs':evs,'total':total,'avg':avg,'result':result})		
