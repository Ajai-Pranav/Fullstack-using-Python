from django.urls import path
from studentapp import views

urlpatterns=[
	path('',views.login),
	path('checklogin',views.checklogin),
	path('markinput',views.marklist),
	path('studd',views.mark),	
]
