import pymysql
import os
from flask import *
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

from sqlalchemy import create_engine,text
from sqlalchemy.orm import scoped_session,sessionmaker

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

engine=create_engine("mysql+pymysql://root@localhost:3306/dashb")
db=scoped_session(sessionmaker(bind=engine))


app=Flask(__name__)
app.debug=True

@app.route("/")
def home():
	return render_template("dash.html")


@app.route("/addp")
def addp():
	print("add page")
	return render_template("add.html")

@app.route("/add",methods=["GET","POST"])
def add():
	if request.method=="POST":
		name=request.form.get("textn")
		code=request.form.get("code")
		price=request.form.get("textp")
		material=request.form.get("textm")
		quantity=request.form.get("qnumber")

		photo = request.files['file']
		
		fname=photo.filename
		target = os.path.join(APP_ROOT,"static/photo")
		print(target)
		destination = "/" . join([target,fname])
		photo.save(destination)

		
		db.execute(text("INSERT INTO prod(itemc ,itemn ,price ,material ,photo ,quantity) VALUES(:itemc ,:itemn ,:price ,:material ,:photo ,:quantity)"),{"itemc":code,"itemn":name,"price":price,"material":material,"photo":fname,"quantity":quantity})
		db.commit()
		res="Details Stored Successfully"
		return render_template("add.html",result=res)

@app.route("/check",methods=["GET","POST"])
def check():
	if request.method=="POST":
		print("test")
		code=request.form.get("code")
		v=db.execute(text("select count(*) from prod")).fetchall()
		w=db.execute(text("select itemc from prod")).fetchall()
		db.commit()
		print(v[0])
		x=0
		msg=""
		for i in v[0]:
			x=i

		for i in range(x):
			for j in w[i]:
				if(j==code):
					msg="Already Item Code Exists"
					print("repeated")
					break
				else:
					msg="You can Proceed"
					continue

		return render_template("add.html",result=msg)


@app.route("/modify/<string:itemc>",methods=["GET"])
def modify(itemc):
	qry = db.execute(text("Select * from prod where itemc=:itemc"),{"itemc":itemc}).fetchone()
	db.commit()
	return render_template("modify.html",result=qry)


@app.route("/delete/<string:itemc>",methods=["GET"])
def delete(itemc):
	db.execute(text("Delete from prod WHERE itemc=:itemc"),{"itemc":itemc})
	db.commit()
	return redirect(url_for('view'))

@app.route("/view")
def view():
	qry = db.execute(text("Select * from prod")).fetchall()
	db.commit()
	return render_template("view.html",result=qry)

@app.route("/order")
def order():
	qry = db.execute(text("Select * from orders")).fetchall()
	db.commit()
	return render_template("orders.html",result=qry)

@app.route("/updaterecord",methods=["GET","POST"])
def updaterecord():
	if request.method=="POST":
		code=request.form.get("code")
		name=request.form.get("textn")
		price=request.form.get("textp")
		material=request.form.get("textm")
		quantity=request.form.get("qnumber")

		
		db.execute(text("Update prod SET itemc=:itemc ,itemn=:itemn ,price=:price ,material=:material ,quantity=:quantity WHERE itemc=:itemc"),{"itemc":code ,"itemn":name ,"price":price ,"material":material ,"quantity":quantity})
		db.commit()
		res="Details Stored Successfully"
		return render_template("view.html",)



if __name__ == "__main__":
	app.run()
	
