$('#spost').submit(function(){
alert("text");
var formData = new FormData(this);
$.ajax({
     url:'/ajaxpost/',
     type: 'POST',
     data: formData,
     success: function (response) {
     	alert("ok");
     },
     error: function (response) {
     	alert("not ok");

     }
});