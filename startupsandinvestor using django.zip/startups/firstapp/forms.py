from django import forms
from firstapp.models import starterpost

class postt(forms.ModelForm):
	class Meta:
		model = starterpost
		fields = ['uname', 'om', 'newfile','category']