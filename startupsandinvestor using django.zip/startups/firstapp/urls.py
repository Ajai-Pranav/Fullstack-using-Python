from django.urls import path
from firstapp import views
from firstapp.custome_view import admin,investor,startup


urlpatterns = [
	path('',views.entry),
	path('einvest',views.einvest),
	path('elearn',views.elearn),
	path('esuccess',views.esuccess),
	path('login',views.login),
	path('logincheck',views.logincheck),
	path('signup',views.signup),
	path('Validatenames/',views.Validatenames),
	path('Validatenamei/',views.Validatenamei),
	path('ajaxregister/',views.ajaxregister),

#admin------------------------------------------
	path('adminlogin',views.adminlogin),
	path('adminlogincheck',views.adminlogincheck),
	path('adminloginsuccess',admin.adminloginsuccess),
	path('ahome',admin.ahome),
	path('abusiness',admin.abusiness),
	path('ainvestors',admin.viewinvestor),
	path('areports',admin.areports),
	path('astartups',admin.viewstartups),
	path('athreshold',admin.athreshold),
	path('viewproject/<str:name>',admin.viewproject),
	path('goback',admin.viewstartups),


#startups-------------------------------------------	

	path('startloginsuccess',startup.startloginsuccess),
	path('shome',startup.shome),
	path('sinvestors',startup.viewinvestor),
	path('senquries',startup.schat),
	path('spost',startup.viewpost),
	path('sprofile',startup.profile),
	# path('ajaxpost/',startup.ajaxpost),
	path('postfile',startup.postfile),
	path('sprofileedit',startup.profileedit),
	# path('finalpost/',startup.finalpost),
	path('simplepost',startup.simplepost),
	path('updateprofile',startup.updateprofile),
	path('updated',startup.profile),
	path('editpost/<int:id>',startup.editpost),
	path('delp/<int:id>',startup.delp),
	path('chat/<str:name>',startup.instachat),
	path('mes',startup.message),
	path('takechat/<str:name>/',startup.takechat),
	path('smess',startup.message1),
	path('acceptedinvestor',startup.acceptedinvestor),

#investors-------------------------------------------

	path('investorloginsuccess',investor.investorloginsuccess),
	path('ihome',investor.ihome),
	path('iinvestors',investor.viewinvestor),
	path('ireplies',investor.ichat),
	path('istartups',investor.viewstartups),
	path('iprofile',investor.iprofile),
	path('iprofileedit',investor.iprofileedit),
	path('iupdateprofile',investor.iupdateprofile),
	path('investorupdated',investor.iprofile),
	path('ichat/<str:uname>',investor.instachat),
	path('imes',investor.message),
	path('itakechat/<str:name>/',investor.itakechat),
	path('imess',investor.message1),
	path('iaccept/<int:id>',investor.accepted),
	path('acceptedover',investor.acceptedover),
	path('gobackacc',investor.viewstartups),
]