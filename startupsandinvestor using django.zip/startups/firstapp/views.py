from django.shortcuts import render,redirect
from django.contrib import messages
from django.http import HttpResponseRedirect,HttpResponse,HttpRequest
from firstapp.models import logindetails,investorlogindetails,startuplogindetails
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse

# Create your views here.
def entry(request):
	return render(request,'ehome.html')

def einvest(request):
	return render(request,'einvest.html')

def elearn(request):
	return render(request,'elearn.html')	

def esuccess(request):
	return render(request,'esuccess.html')	

def login(request):
	return render(request,'login.html')	

def adminlogin(request):
	return render(request,'adminlog.html')	

def adminlogincheck(request):
	if request.method == 'POST':
		uname = request.POST['username']
		pwd = request.POST['pwd']

		
		
		if logindetails.objects.filter(name=uname,password=pwd).exists():
			#return render(request,'newuser.html')
			#request.session['user']=uname

			return HttpResponseRedirect('adminloginsuccess')
			#return render(request, 'loginsuccess.html')

		else:
			#return HttpResponse("Invalid Login")
			#return render(request, 'index.html', {res:"Invalid Login"})
			messages.info(request,"Invalid Login")
			return render(request, 'adminlog.html')

	else:
		return render(request, 'adminlog.html')


def logincheck(request):
	if request.method == 'POST':
		uname = request.POST['uname']
		pwd = request.POST['password']
		n=request.POST['optradio']

		if(n=='1'):

			if startuplogindetails.objects.filter(name=uname,password=pwd).exists():
				#return render(request,'newuser.html')
				request.session['user']=uname

				return HttpResponseRedirect('startloginsuccess')
				#return render(request, 'loginsuccess.html')

			else:
				#return HttpResponse("Invalid Login")
				#return render(request, 'index.html', {res:"Invalid Login"})
				messages.info(request,"Invalid Login")
				return render(request, 'login.html')

		if(n=='2'):
			if investorlogindetails.objects.filter(name=uname,password=pwd).exists():
				#return render(request,'newuser.html')
				request.session['user']=uname

				return HttpResponseRedirect('investorloginsuccess')
				#return render(request, 'loginsuccess.html')

			else:
				#return HttpResponse("Invalid Login")
				#return render(request, 'index.html', {res:"Invalid Login"})
				messages.info(request,"Invalid Login")
				return render(request, 'login.html')

def signup(request):
	return render(request, 'signup.html')

#-------------------------------------------------------


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'
    
def Validatenames(request):
	uname = request.GET.get('Name', None)
	print("startup",uname)
	data = {
	'is_present': startuplogindetails.objects.filter(name=uname).exists()
	}
	print(data)
	return JsonResponse(data)		

def Validatenamei(request):
	uname = request.GET.get('Name', None)
	print("investor",uname)
	data = {
	'is_present': investorlogindetails.objects.filter(name=uname).exists()
	}
	print(data)
	return JsonResponse(data)					


def ajaxregister(request):

	if is_ajax and request.method == "POST":
		
		frm=request.POST

		n=request.POST["uname"]
		
		o=frm.get("comp")
		uname = frm.get("uname")
		password = frm.get("password")
		dob=frm.get("date")


		if(o=="STARTUP"):
			stud=startuplogindetails()
			stud.name=uname	
			stud.password=password
			stud.dob=dob
			stud.photo="defaultprofile.jpeg"
			stud.save()
			res="Success"
			return JsonResponse({"data": res})

		elif(o=="INVESTOR"):
			stud=investorlogindetails()
			stud.name=uname	
			stud.password=password
			stud.dob=dob
			stud.photo="defaultprofile.jpeg"
			stud.save()
			res="Success"
			return JsonResponse({"data": res})		