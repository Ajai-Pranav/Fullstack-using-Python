from django.db import models

# Create your models here.

class logindetails(models.Model):
	
	name=models.CharField(max_length=25)
	password=models.CharField(max_length=10)
	
	class Meta:
		db_table="admin"

class investorlogindetails(models.Model):
	
	name=models.CharField(max_length=25)
	password=models.CharField(max_length=10)
	dob=models.DateField()
	phone=models.BigIntegerField(null=True)
	photo=models.FileField(null=True)
	address=models.CharField(max_length=300,null=True)
	investcap=models.IntegerField(null=True)

	class Meta:
		db_table="investor"

class startuplogindetails(models.Model):
	
	name=models.CharField(max_length=25)
	password=models.CharField(max_length=10)
	dob=models.DateField()
	categories=models.CharField(max_length=50,null=True)
	phone=models.BigIntegerField(null=True)
	photo=models.FileField(null=True)
	address=models.CharField(max_length=300,null=True)
	
	class Meta:
		db_table="startup"		
 
class starterpost(models.Model):
	uname=models.CharField(max_length=100)
	om=models.CharField(max_length=500,null=True)
	newfile=models.FileField(max_length=300, upload_to='', blank=True,null=True)
	category=models.CharField(max_length=100,null=True)
	investment=models.IntegerField(null=True)
	pdff=models.FileField(max_length=300,null=True)

	class Meta:
		db_table="post"

class chatbox(models.Model):
	sname=models.CharField(max_length=100)
	rname=models.CharField(max_length=100)
	message=models.CharField(max_length=500,null=True)
	file=models.FileField(max_length=300,null=True)

	class Meta:
		db_table="chat"		


class acceptedd(models.Model):
	sname=models.CharField(max_length=50,null=True)
	iname=models.CharField(max_length=50,null=True)
	sid=models.IntegerField()		

	class Meta:
		db_table="accepted"