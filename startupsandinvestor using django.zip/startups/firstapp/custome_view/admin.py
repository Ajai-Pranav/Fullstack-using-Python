from django.shortcuts import render,redirect
from django.contrib import messages
from django.http import HttpResponseRedirect,HttpResponse,HttpRequest
from firstapp.models import logindetails,investorlogindetails,startuplogindetails,starterpost

def adminloginsuccess(request):
	return render(request,'admin/home.html')

def ahome(request):
	return render(request,'admin/home.html')		

def ainvestors(request):
	return render(request,'admin/investors.html')	

# def astartups(request):
# 	return render(request,'admin/startups.html')

def areports(request):
	return render(request,'admin/reports.html')	

def athreshold(request):
	return render(request,'admin/threshold.html')

def abusiness(request):
	return render(request,'admin/business.html')

def viewstartups(request):
	res=startuplogindetails.objects.all()

	return render(request,'admin/startups.html',{'result':res})	

def viewinvestor(request):
	res=investorlogindetails.objects.all()

	return render(request,'admin/investors.html',{'result':res})	

def viewproject(request,name):
	res=starterpost.objects.filter(uname=name)

	return render(request,'admin/projects.html',{'result':res})	

