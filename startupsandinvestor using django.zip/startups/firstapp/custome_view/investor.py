from django.shortcuts import render,redirect
from django.contrib import messages
from django.http import HttpResponseRedirect,HttpResponse,HttpRequest
from firstapp.models import logindetails,investorlogindetails,startuplogindetails,starterpost,chatbox,acceptedd
from django.db.models import Q


def investorloginsuccess(request):
	return render(request,'investor/home.html')

def ihome(request):
	return render(request,'investor/home.html')	

def iinvestors(request):
	return render(request,'investor/investors.html')

# def ireplies(request):
# 	n=request.session["user"]
# 	res=chatbox.objects.filter(Q(rname=n)|Q(sname=n))
# 	return render(request,'investor/replies.html',{'result':res})

def istartups(request):
	return render(request,'investor/startups.html')	

# def iprofile(request):
# 	return render(request,'investor/profile.html')	

# def iprofileedit(request):
# 	return render(request,'investor/profileedit.html')		

def iprofile(request):
	n = request.session["user"]
	r=investorlogindetails.objects.get(name=n)

	return render(request,'investor/profile.html',{'result':r})

def iprofileedit(request):
	n = request.session["user"]
	r=investorlogindetails.objects.get(name=n)

	return render(request,'investor/profileedit.html',{'result':r})

def iupdateprofile(request):
	if request.method=="POST":
		n = request.POST['name']
		# d = request.POST['DOB']
		p=request.POST['phone']
		ad=request.POST['address']
		photo=request.FILES['photo']
		ic=request.POST['capacity']
		ne= request.session["user"]
		# o=tuple(request.POST['options[]',[]])
		# print(o)

		s=investorlogindetails.objects.get(name=ne)
		# s.dob=d
		s.name=n
		s.phone=p
		s.address=ad
		s.photo=photo
		s.investcap=ic
		s.save()
		res="Updated Successfully"
		return HttpResponseRedirect("/investorupdated")	

def viewstartups(request):
	res=starterpost.objects.all()

	return render(request,'investor/startups.html',{'result':res})			

def viewinvestor(request):
	res=investorlogindetails.objects.all()

	return render(request,'investor/investors.html',{'result':res})	

def viewpdf(request,id):
	res=starterpost.objects.get(id=id)

	return render(request,'investor/pdf.html',{'s':res})	

def instachat(request,uname):
	return render(request,'investor/iinstachat.html',{'s':uname})

def message(request):
	if request.method == 'POST':
		n=request.session["user"]
		m=request.POST["m"]
		r=request.POST["recive"]
		c=chatbox()
		c.sname=n
		c.rname=r
		c.message=m
		c.save()
		return HttpResponseRedirect("/ireplies")		

# def accepted(request,id):
# 	r=starterpost.objects.get(id=id)
def ichat(request):
	# n=request.session["user"]
	# res=chatbox.objects.filter(Q(rname=n)|Q(sname=n))
	# en=set()
	# fr=[]
	# for s in res:
	# 	if (s.rname not in en or s.sname not in en):
	# 		fr.append(s)
	# 		en.add(s.rname)
	# 		en.add(s.sname)
	ir=startuplogindetails.objects.all()
	return render(request,'investor/ichat.html',{'result':ir})

def itakechat(request,name):
	n=request.session["user"]
	ir=startuplogindetails.objects.all()
	rn=chatbox.objects.filter((Q(rname=name) | Q(sname=name)) & (Q(rname=n) | Q(sname=n)))
	return render(request,'investor/replies.html',{'messa':rn,'result':ir,'r':name})	

def message1(request):
	if request.method == 'POST':
		sender=request.session["user"]
		messag=request.POST["m"]
		rec=request.POST["recive"]
		print(rec)
		c=chatbox()
		c.sname=sender
		c.rname=rec
		c.message=messag
		c.save()
		return HttpResponseRedirect("/itakechat/%s"%rec)	

def accepted(request,id):
	n=request.session["user"]
	s=id
	a=acceptedd()
	a.sname="no need"
	a.iname=n
	a.sid=s
	a.save()
	return HttpResponseRedirect("/acceptedover")

def acceptedover(request):
	d1=acceptedd.objects.values_list('sid', flat=True)
	print(d1)
	# cid=starterpost.objects.get(id=d1)
	# print(cid)
	# d2=starterpost.objects.filter(id=d1[0])
	seen_sid_values = set()
	d2_list = []
	for sid_value in d1:
		if sid_value not in seen_sid_values:
			filtered_objects = starterpost.objects.filter(id=sid_value)
			d2_list.extend(filtered_objects)
			seen_sid_values.add(sid_value)
	return render(request,'investor/iaccepted.html',{'result':d2_list})	