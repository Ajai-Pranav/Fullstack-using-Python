from django.shortcuts import render,redirect
from django.contrib import messages
from django.http import HttpResponseRedirect,HttpResponse,HttpRequest
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from firstapp.models import logindetails,investorlogindetails,startuplogindetails,starterpost,chatbox,acceptedd
from firstapp.forms import postt
from firstapp.models import starterpost
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q


from django.core import serializers

import json
from django.views.generic.edit import View
from django.http import JsonResponse


def startloginsuccess(request):
	return render(request,'startup/home.html')

def shome(request):
	return render(request,'startup/home.html')	

def sinvestors(request):
	return render(request,'startup/investors.html')

# def senquries(request):
# 	# n=request.session["user"]
# 	# res=chatbox.objects.filter(Q(rname=n)|Q(sname=n))
# 	# en=set()
# 	# fr=[]
# 	# for s in res:
# 	# 	if (s.rname not in en or s.sname not in en):
# 	# 		fr.append(s)
# 	# 		en.add(s.rname)
# 	# 		en.add(s.sname)
# 	# return render(request,'startup/enquries.html',{'result':fr})
# 	return render(request,'startup/enquries.html')

def spost(request):
	return render(request,'startup/posts.html')	

def sprofile(request):
	return render(request,'startup/profile.html')	

def postfile(request):
	return render(request,'startup/postfile.html')

def sprofileedit(request):
	return render(request,'startup/profileedit.html')


# def profileupdate(request):
# 	if request.session.has_key("user"):
# 		n=request.session["user"]
# 		obj = startuplogindetails.objects.get(name=n)
# 		return render(request,'startup/profile.html',{'su':obj})


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


#-----------------------------------Getting the post -----------------------------------
def simplepost(request):
	if request.method == 'POST':
		n = request.session["user"]
		f=request.FILES["detailfile"]
		om=request.POST["openmessage"]
		category=request.POST["category"]
		rf=request.FILES["reffile"]
		i=request.POST["invest"]
		p=starterpost()
		p.uname=n
		p.om=om
		p.category=category
		p.newfile=f
		p.pdff=rf
		p.investment=i
		p.save()
		res="Posted Successfully"
		return render(request,'startup/postfile.html',{'result':res})


# def ajaxpost(request):
# 	if is_ajax(request=request) and request.method == "POST":
# 		print("hi")
# 		print("I am ok")
#     	n = request.session["user"]
#     	f = request.FILES["detailfile"]
#     	om = request.POST.get("openmessage")
#     	category=request.POST.get("category")
#     	stud = starterpost()
#     	stud.uname = n
#     	stud.category=category
#     	stud.om = om
#     	stud.file = f
#     	stud.save()
#     	res = "Success"

#     	return JsonResponse({"data": res})


# def finalpost(request):
# 	print("*************************")
  
# 	if is_ajax and request.method == "POST":
# 		print("*************************")
# 		form = postt(request.POST, request.FILES)
# 		if form.is_valid():
# 			print("*************************")
# 			instance = form.save()
# 			return JsonResponse({'success': True,'data': 'Posted successfully','image_url': instance.newfile.url})
# 		else:
# 			errors = form.errors.as_json()
# 			print(errors)
# 			return JsonResponse({'success': False, 'data': errors})

#--------------------------------------------------------------------------------------------------------------------------------------


def viewpost(request):
	n = request.session["user"]
	res=starterpost.objects.filter(uname=n)

	return render(request,'startup/posts.html',{'result':res})
	
# -------------------------------------------------------------------------------------------------------------
def profile(request):
	n = request.session["user"]
	res=startuplogindetails.objects.get(name=n)

	return render(request,'startup/profile.html',{'result':res})

def profileedit(request):
	n = request.session["user"]
	res=startuplogindetails.objects.get(name=n)

	return render(request,'startup/profileedit.html',{'result':res})

def updateprofile(request):
	if request.method=="POST":
		n = request.POST['name']
		# d = request.POST['DOB']
		p=request.POST['phone']
		ad=request.POST['address']
		photo=request.FILES['photo']
		print("888888888888888888888888888888")
		ne= request.session["user"]

		s=startuplogindetails.objects.get(name=ne)
		# s.dob=d
		s.name=n
		s.phone=p
		s.address=ad
		s.photo=photo
		s.save()
		res="Updated Successfully"
		return HttpResponseRedirect("/updated")
		# return render(request,'updated')	

def viewinvestor(request):
	res=investorlogindetails.objects.all()

	return render(request,'startup/investors.html',{'result':res})		
# -----------------------------------------------------------------------------------------------------------------------

def editpost(request,id):
	res=starterpost.objects.filter(id=id)
	return render(request,'startup/editpost.html',{'s':res})

def updatepost(request):
	if request.method == 'POST':
		# n = request.session["user"]
		f=request.FILES["detailfile"]
		om=request.POST["openmessage"]
		category=request.POST["category"]
		rf=request.FILES["reffile"]
		i=request.POST["investment"]
		p=starterpost()
		# p.uname=n
		p.om=om
		p.category=category
		p.newfile=f
		p.pdff=rf
		p.investment=i
		p.save()
		return render(request,'startup/viewpost')	

def delp(request,id):
	result=starterpost.objects.get(id=id)
	result.delete()

	return HttpResponseRedirect("/spost")		

def instachat(request,name):
	return render(request,'startup/sinstachat.html',{'s':name})

def message(request):
	if request.method == 'POST':
		n=request.session["user"]
		m=request.POST["m"]
		r=request.POST["recive"]
		c=chatbox()
		c.sname=n
		c.rname=r
		c.message=m
		c.save()
		return HttpResponseRedirect("/senquries")

def schat(request):
	# n=request.session["user"]
	# res=chatbox.objects.filter(Q(rname=n)|Q(sname=n))
	# en=set()
	# fr=[]
	# for s in res:
	# 	if (s.rname not in en or s.sname not in en):
	# 		fr.append(s)
	# 		en.add(s.rname)
	# 		en.add(s.sname)
	ir=investorlogindetails.objects.all()
	return render(request,'startup/schat.html',{'result':ir})

def takechat(request,name):
	n=request.session["user"]
	ir=investorlogindetails.objects.all()
	rn=chatbox.objects.filter((Q(rname=name) | Q(sname=name)) & (Q(rname=n) | Q(sname=n)))
	return render(request,'startup/enquries.html',{'messa':rn,'result':ir,'re':name})

def message1(request):
	if request.method == 'POST':
		sender=request.session["user"]
		messag=request.POST["m"]
		rec=request.POST["recive"]
		print(rec)
		c=chatbox()
		c.sname=sender
		c.rname=rec
		c.message=messag
		c.save()
		return HttpResponseRedirect("/takechat/%s"%rec)

def acceptedinvestor(request):
	d1=acceptedd.objects.values_list('sid', flat=True)
	n=request.session["user"]
	tt=acceptedd.objects.all()
	# cid=starterpost.objects.get(id=d1)
	# print(cid)
	# d2=starterpost.objects.filter(id=d1[0])
	seen_sid_values = set()
	d2_list = []
	for sid_value in d1:
		if sid_value not in seen_sid_values:
			filtered_objects = starterpost.objects.filter(id=sid_value)
			d2_list.extend(filtered_objects)
			seen_sid_values.add(sid_value)
	# if n in d2_list.name:
	# 	d5=acceptedd.objects.get(sid=d2_list.id)				
	return render(request,'startup/accepted.html',{'result':d2_list,'invest':tt})	